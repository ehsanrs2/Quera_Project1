# Coffee_shop_Quera_Project1
هدف این پروژه استخراج داده‌هایی از کافی‌شاپ‌های سراسر کشور و تحلیل آن‌ هاست

    Root.
        ├── src     # Source files Scripts for web scraping using tools like BeautifulSoup, Selenium, etc.
        |    ├── web_scraping.py
        |    ├── fidilio.csv
        |    ├── fidilio.log
        |    └── ...
        ├── database 
        |    ├── sql_src.py or sql_src.sql # SQL scripts for creating database tables.
        |    ├── sql_insert.py or sql_insert.sql # Scripts for inserting scraped data into the database.
        |    └── ...
        ├── dashboard
        |   ├── report.pbix # Power BI report files for creating the dashboard.
        |   └── ...
        └── README.md # Explanation of project structure, tools used, and instructions for executing each part of the project.

